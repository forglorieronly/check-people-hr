#!/usr/bin/env python3
"""
Сглобява самостоятелен HTML файл от шаблона и CSV с кандидати.

Употреба:
    python3 scripts/build.py                          # data/candidates.csv -> index.html
    python3 scripts/build.py data/other.csv           # друг вход
    python3 scripts/build.py data/other.csv out.html  # друг вход и изход

Резултатът е един файл без външни зависимости. Отваря се с двойно
щракване и работи офлайн.
"""

import csv
import io
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "src" / "template.html"
PLACEHOLDER = "__REGISTER__"


def read_csv(path: Path):
    """Чете CSV с UTF-8 BOM и сам разпознава разделителя (, или ;)."""
    text = path.read_text(encoding="utf-8-sig")
    sample = text.split("\n", 1)[0]
    delimiter = ";" if sample.count(";") > sample.count(",") else ","

    rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
    rows = [r for r in rows if any(c.strip() for c in r)]
    if not rows:
        raise SystemExit(f"Файлът {path} е празен.")

    headers = [h.strip() for h in rows[0]]
    width = len(headers)
    body = [[(r[i].strip() if i < len(r) else "") for i in range(width)] for r in rows[1:]]
    return headers, body


def build(csv_path: Path, out_path: Path) -> None:
    if not TEMPLATE.exists():
        raise SystemExit(f"Липсва шаблонът: {TEMPLATE}")
    if not csv_path.exists():
        raise SystemExit(f"Липсва CSV файлът: {csv_path}")

    headers, rows = read_csv(csv_path)
    payload = json.dumps(
        {"headers": headers, "rows": rows},
        ensure_ascii=False,
        separators=(",", ":"),
    )

    html = TEMPLATE.read_text(encoding="utf-8")
    if PLACEHOLDER not in html:
        raise SystemExit(f"В шаблона няма {PLACEHOLDER}.")

    html = html.replace(PLACEHOLDER, f"var REGISTER = {payload};")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    size_kb = out_path.stat().st_size / 1024
    print(f"Готово: {out_path}")
    print(f"  {len(rows)} записа, {len(headers)} колони, {size_kb:.1f} KB")
    print(f"  Колони: {', '.join(headers)}")


if __name__ == "__main__":
    csv_arg = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "candidates.csv"
    out_arg = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "index.html"
    build(csv_arg, out_arg)
